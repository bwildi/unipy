# unipy
UniPy is a Python 3 package for pulling raw data from the Unity Analytics REST API: https://docs.unity3d.com/Manual/UnityAnalyticsRawDataExport.html
